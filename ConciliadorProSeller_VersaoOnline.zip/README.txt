
# Conciliador Pró Seller - Versão Online

Este sistema permite que sellers da Amazon conciliem seus relatórios de vendas e financeiros.

## Como usar:

1. Acesse https://app.netlify.com
2. Crie uma conta gratuita (ou use a sua já criada)
3. Clique em "Add new site" > "Deploy manually"
4. Arraste os arquivos deste ZIP para a área de upload
5. O Netlify irá gerar um link automático

## Funcionalidades:
- Upload de .txt e .csv
- Cálculo de imposto (10%)
- Valor líquido e repassado
- Exportação de relatório em Excel (formato .csv)

Senha de proteção pode ser adicionada com Netlify Gate ou versão com backend em breve.

Desenvolvido para Ewerton com dedicação.
