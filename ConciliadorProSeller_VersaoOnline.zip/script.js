
function processar() {
  const pedidoInput = document.getElementById("pedidoFile");
  const financeiroInput = document.getElementById("financeiroFile");
  const mensagem = document.getElementById("mensagem");

  if (!pedidoInput.files[0] || !financeiroInput.files[0]) {
    mensagem.innerText = "Por favor, envie os dois arquivos.";
    return;
  }

  const readerPedido = new FileReader();
  const readerFinanceiro = new FileReader();

  readerPedido.onload = function (e) {
    const pedidoData = e.target.result;
    readerFinanceiro.onload = function (e2) {
      const financeiroData = e2.target.result;

      const pedidos = pedidoData.split('\n').slice(1).map(l => l.split('\t')).filter(l => l.length > 2);
      const transacoes = financeiroData.split('\n').slice(1).map(l => l.split(',')).filter(l => l.length > 1);

      const resultado = pedidos.map(p => {
        const pedido_id = p[0];
        const produto = p[1];
        const valor_bruto = parseFloat(p[2].replace(',', '.'));
        const imposto = valor_bruto * 0.10;
        const transacao = transacoes.find(t => t[0] === pedido_id);
        const repassado = transacao ? parseFloat(transacao[1]) : 0;
        const liquido = valor_bruto - imposto;

        return [pedido_id, produto, valor_bruto.toFixed(2), imposto.toFixed(2), liquido.toFixed(2), repassado.toFixed(2)];
      });

      let csv = "Pedido ID,Produto,Valor Bruto,Imposto (10%),Valor Líquido,Repassado pela Amazon\n";
      resultado.forEach(linha => {
        csv += linha.join(",") + "\n";
      });

      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "relatorio_conciliado.csv";
      link.click();
    };
    readerFinanceiro.readAsText(financeiroInput.files[0]);
  };
  readerPedido.readAsText(pedidoInput.files[0]);
}
